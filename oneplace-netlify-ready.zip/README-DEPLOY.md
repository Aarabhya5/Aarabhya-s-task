# OnePlace — Netlify deployment package

This is a static website package. `index.html` is at the ZIP root and contains the embedded hero artwork, CSS, and JavaScript.

## Deploy with Netlify Drop
1. Download this ZIP and extract it on your computer.
2. Open Netlify Drop: https://app.netlify.com/drop
3. Drag the extracted folder (the folder containing `index.html`) onto the Netlify Drop page.
4. Wait for deployment. Netlify will provide a public `*.netlify.app` URL.
5. Open the URL and test the landing page, then click **Start Studying** to test the app.

## Important
- Upload the extracted folder, not the ZIP file, if Netlify Drop does not accept ZIP uploads.
- Keep `index.html` at the top level of the folder.
- This MVP stores tasks and XP in the visitor's browser LocalStorage. It does not yet have cloud accounts or cross-device sync.
